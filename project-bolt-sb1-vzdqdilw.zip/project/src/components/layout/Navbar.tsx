import React, { useState, useEffect } from 'react';
import { Menu, X, ArrowRight, BrainCircuit } from 'lucide-react';
import Container from '../ui/Container';
import Button from '../ui/Button';

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <nav
      className={`sticky top-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-3' : 'bg-transparent py-5'
      }`}
    >
      <Container className="flex items-center justify-between">
        <div className="flex items-center">
          <BrainCircuit className="text-blue-600 h-8 w-8 mr-2" />
          <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            NexusAI
          </span>
        </div>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-8">
          <NavLinks />
          <div className="flex items-center space-x-3">
            <Button variant="outline" size="sm">
              Log in
            </Button>
            <Button size="sm">
              Get Started <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Mobile Navigation Toggle */}
        <div className="md:hidden">
          <button
            onClick={toggleMenu}
            className="text-gray-700 focus:outline-none"
            aria-label={isMenuOpen ? 'Close menu' : 'Open menu'}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </Container>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-white shadow-lg py-4 px-4 transition-all duration-300">
          <div className="flex flex-col space-y-4">
            <NavLinksMobile toggleMenu={toggleMenu} />
            <div className="flex flex-col space-y-2 pt-2 border-t border-gray-100">
              <Button variant="outline" fullWidth>
                Log in
              </Button>
              <Button fullWidth>
                Get Started <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

const NavLinks: React.FC = () => {
  return (
    <>
      <a
        href="#features"
        className="text-gray-700 hover:text-blue-600 font-medium transition-colors"
      >
        Features
      </a>
      <a
        href="#solutions"
        className="text-gray-700 hover:text-blue-600 font-medium transition-colors"
      >
        Solutions
      </a>
      <a
        href="#pricing"
        className="text-gray-700 hover:text-blue-600 font-medium transition-colors"
      >
        Pricing
      </a>
      <a
        href="#testimonials"
        className="text-gray-700 hover:text-blue-600 font-medium transition-colors"
      >
        Testimonials
      </a>
    </>
  );
};

interface NavLinksMobileProps {
  toggleMenu: () => void;
}

const NavLinksMobile: React.FC<NavLinksMobileProps> = ({ toggleMenu }) => {
  return (
    <>
      <a
        href="#features"
        className="text-gray-700 hover:text-blue-600 font-medium py-2"
        onClick={toggleMenu}
      >
        Features
      </a>
      <a
        href="#solutions"
        className="text-gray-700 hover:text-blue-600 font-medium py-2"
        onClick={toggleMenu}
      >
        Solutions
      </a>
      <a
        href="#pricing"
        className="text-gray-700 hover:text-blue-600 font-medium py-2"
        onClick={toggleMenu}
      >
        Pricing
      </a>
      <a
        href="#testimonials"
        className="text-gray-700 hover:text-blue-600 font-medium py-2"
        onClick={toggleMenu}
      >
        Testimonials
      </a>
    </>
  );
};

export default Navbar;