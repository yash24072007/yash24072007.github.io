import React, { useState } from 'react';
import { Play, Pause, ChevronRight } from 'lucide-react';
import Container from '../ui/Container';
import Button from '../ui/Button';

const DemoSection: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  return (
    <section id="solutions" className="py-20 bg-gradient-to-b from-white to-gray-50">
      <Container>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              See our AI in action
            </h2>
            <p className="text-gray-600 text-lg mb-6">
              Experience how our AI platform transforms complex data into actionable insights, automates repetitive tasks, and drives business growth.
            </p>

            <div className="space-y-4 mb-8">
              {['Data Processing', 'Predictive Analytics', 'Natural Language Understanding', 'Automated Decision Making'].map((item, index) => (
                <div key={index} className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <ChevronRight className="h-5 w-5 text-blue-600" />
                  </div>
                  <div className="ml-2">
                    <h4 className="font-medium text-gray-900">{item}</h4>
                    <p className="text-gray-600">
                      {index === 0 && 'Process and analyze vast amounts of data in seconds.'}
                      {index === 1 && 'Forecast trends and anticipate market changes with precision.'}
                      {index === 2 && 'Understand customer needs through advanced language processing.'}
                      {index === 3 && 'Let AI handle routine decisions while you focus on strategy.'}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            <Button size="lg">
              Schedule a Live Demo
            </Button>
          </div>

          <div className="relative">
            <div className="rounded-xl overflow-hidden shadow-xl">
              <img 
                src="https://images.pexels.com/photos/9822732/pexels-photo-9822732.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                alt="NexusAI Dashboard Demo"
                className="w-full h-auto"
              />
              <div className="absolute inset-0 bg-gray-900/20 flex items-center justify-center">
                <button 
                  className="h-16 w-16 bg-white rounded-full flex items-center justify-center shadow-lg transform transition-transform hover:scale-110"
                  onClick={togglePlay}
                  aria-label={isPlaying ? 'Pause demo video' : 'Play demo video'}
                >
                  {isPlaying ? (
                    <Pause className="h-6 w-6 text-blue-600" />
                  ) : (
                    <Play className="h-6 w-6 text-blue-600 ml-1" />
                  )}
                </button>
              </div>
            </div>

            <div className="absolute -z-10 -bottom-6 -right-6 h-full w-full bg-gradient-to-tr from-blue-200 to-purple-200 rounded-xl"></div>
          </div>
        </div>
      </Container>
    </section>
  );
};

export default DemoSection;