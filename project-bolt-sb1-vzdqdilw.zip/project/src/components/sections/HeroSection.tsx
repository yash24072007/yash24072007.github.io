import React from 'react';
import { Play, ArrowRight } from 'lucide-react';
import Container from '../ui/Container';
import Button from '../ui/Button';

const HeroSection: React.FC = () => {
  return (
    <section className="pt-20 pb-16 overflow-hidden">
      <Container>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="max-w-xl">
            <div className="flex items-center space-x-2 bg-blue-50 text-blue-600 py-1 px-3 rounded-full w-fit mb-6">
              <span className="inline-block h-2 w-2 rounded-full bg-blue-600"></span>
              <span className="text-sm font-medium">Redefining AI Solutions</span>
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                AI-Powered
              </span>{' '}
              Solutions for the Modern Enterprise
            </h1>
            <p className="text-gray-600 text-lg mb-8">
              Transform your business with our cutting-edge AI platform. Automate workflows, gain insights, and boost productivity with intelligent solutions designed for the future.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <Button size="lg">
                Get Started <ArrowRight className="ml-1 h-5 w-5" />
              </Button>
              <Button variant="outline" size="lg">
                <Play className="mr-2 h-5 w-5" /> Watch Demo
              </Button>
            </div>
            <div className="mt-8 flex items-center space-x-4">
              <div className="flex -space-x-2">
                {[1, 2, 3, 4].map((i) => (
                  <img
                    key={i}
                    src={`https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=50&h=50&dpr=2`}
                    alt="User"
                    className="h-8 w-8 rounded-full border-2 border-white"
                  />
                ))}
              </div>
              <div className="text-sm text-gray-500">
                <span className="font-semibold text-gray-700">500+</span> companies already using NexusAI
              </div>
            </div>
          </div>
          <div className="relative">
            <div className="relative bg-gradient-to-tr from-blue-100 to-purple-100 p-1 rounded-xl shadow-lg">
              <div className="absolute top-0 left-0 right-0 bottom-0 bg-gradient-to-tr from-blue-500/20 to-purple-500/20 rounded-xl"></div>
              <img 
                src="https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                alt="AI Platform Interface"
                className="rounded-lg shadow-md w-full h-auto"
              />
              <div className="absolute -top-6 -right-6 bg-gradient-to-tr from-blue-500 to-purple-600 p-2 rounded-lg shadow-lg text-white text-sm font-medium animate-bounce">
                New AI Model!
              </div>
            </div>
            
            {/* Decorative blobs */}
            <div className="absolute -z-10 -top-10 -left-10 h-64 w-64 bg-blue-300/30 rounded-full blur-3xl"></div>
            <div className="absolute -z-10 -bottom-10 -right-10 h-64 w-64 bg-purple-300/30 rounded-full blur-3xl"></div>
          </div>
        </div>
      </Container>
    </section>
  );
};

export default HeroSection;