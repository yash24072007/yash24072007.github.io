import React from 'react';
import { BrainCircuit, Star, Zap, Shield, BarChart, Users, MessageSquare, ArrowUpRight } from 'lucide-react';
import Container from '../ui/Container';

const features = [
  {
    icon: <BrainCircuit className="h-6 w-6 text-blue-600" />,
    title: 'Advanced AI Models',
    description: 'Leverage state-of-the-art machine learning models trained on diverse datasets for superior accuracy.',
  },
  {
    icon: <Zap className="h-6 w-6 text-blue-600" />,
    title: 'Lightning Fast',
    description: 'Get instant results with our optimized infrastructure designed for high-performance computing.',
  },
  {
    icon: <Shield className="h-6 w-6 text-blue-600" />,
    title: 'Enterprise Security',
    description: 'Your data is protected with bank-level encryption and strict access controls.',
  },
  {
    icon: <BarChart className="h-6 w-6 text-blue-600" />,
    title: 'Insightful Analytics',
    description: 'Gain actionable insights with comprehensive analytics dashboards and reports.',
  },
  {
    icon: <Users className="h-6 w-6 text-blue-600" />,
    title: 'Team Collaboration',
    description: 'Seamlessly collaborate with your team on AI projects with powerful sharing features.',
  },
  {
    icon: <MessageSquare className="h-6 w-6 text-blue-600" />,
    title: 'Natural Language Processing',
    description: 'Understand and generate human language with our advanced NLP capabilities.',
  },
];

const FeaturesSection: React.FC = () => {
  return (
    <section id="features" className="py-16 bg-gray-50">
      <Container>
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center px-4 py-1 rounded-full bg-blue-100 text-blue-700 mb-4">
            <Star className="h-4 w-4 mr-2" />
            <span className="text-sm font-medium">Powerful Features</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Everything you need to harness the power of AI</h2>
          <p className="text-gray-600 text-lg">
            Our comprehensive platform offers cutting-edge tools and features designed to help you implement AI solutions with ease.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow duration-300"
            >
              <div className="rounded-lg bg-blue-50 p-3 w-fit mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
              <p className="text-gray-600 mb-4">{feature.description}</p>
              <a 
                href="#" 
                className="inline-flex items-center text-blue-600 font-medium hover:text-blue-700 transition-colors"
              >
                Learn more <ArrowUpRight className="ml-1 h-4 w-4" />
              </a>
            </div>
          ))}
        </div>
      </Container>
    </section>
  );
};

export default FeaturesSection;