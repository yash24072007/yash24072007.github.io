import React, { useState } from 'react';
import { Check, X } from 'lucide-react';
import Container from '../ui/Container';
import Button from '../ui/Button';

interface PricingPlan {
  name: string;
  price: {
    monthly: string;
    annually: string;
  };
  description: string;
  features: string[];
  notIncluded?: string[];
  cta: string;
  popular?: boolean;
}

const plans: PricingPlan[] = [
  {
    name: 'Starter',
    price: {
      monthly: '$49',
      annually: '$39',
    },
    description: 'Perfect for individuals and small teams just getting started with AI.',
    features: [
      'Access to basic AI models',
      '10,000 API calls per month',
      'Email support',
      'Basic analytics dashboard',
      'Standard documentation',
    ],
    notIncluded: [
      'Custom AI model training',
      'Advanced integrations',
      'Dedicated account manager',
    ],
    cta: 'Start with Starter',
  },
  {
    name: 'Professional',
    price: {
      monthly: '$99',
      annually: '$79',
    },
    description: 'Ideal for growing businesses looking to leverage AI capabilities.',
    features: [
      'Access to all AI models',
      '50,000 API calls per month',
      'Priority email & chat support',
      'Advanced analytics dashboard',
      'Comprehensive documentation',
      'Basic integrations',
      'Team collaboration tools',
    ],
    cta: 'Go Professional',
    popular: true,
  },
  {
    name: 'Enterprise',
    price: {
      monthly: '$299',
      annually: '$249',
    },
    description: 'Tailored solutions for organizations with advanced AI needs.',
    features: [
      'Access to all AI models including beta',
      'Unlimited API calls',
      '24/7 dedicated support',
      'Complete analytics suite',
      'Custom documentation',
      'Advanced integrations',
      'Team collaboration tools',
      'Custom AI model training',
      'Dedicated account manager',
    ],
    cta: 'Contact Sales',
  },
];

const PricingSection: React.FC = () => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annually'>('monthly');

  const toggleBillingCycle = () => {
    setBillingCycle(billingCycle === 'monthly' ? 'annually' : 'monthly');
  };

  return (
    <section id="pricing" className="py-20">
      <Container>
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Simple, transparent pricing
          </h2>
          <p className="text-gray-600 text-lg mb-8">
            Choose the plan that's right for your business, from startups to enterprise organizations.
          </p>

          <div className="flex items-center justify-center mb-8">
            <span className={`mr-3 ${billingCycle === 'monthly' ? 'text-blue-600 font-medium' : 'text-gray-500'}`}>
              Monthly
            </span>
            <button
              onClick={toggleBillingCycle}
              className="relative inline-flex h-6 w-11 items-center rounded-full"
              role="switch"
              aria-checked={billingCycle === 'annually'}
            >
              <span className="sr-only">Toggle billing cycle</span>
              <span
                className={`${
                  billingCycle === 'annually' ? 'bg-blue-600' : 'bg-gray-300'
                } inline-block h-6 w-11 rounded-full transition`}
              />
              <span
                className={`${
                  billingCycle === 'annually' ? 'translate-x-6' : 'translate-x-1'
                } inline-block h-4 w-4 transform rounded-full bg-white transition`}
              />
            </button>
            <div className="ml-3 flex items-center">
              <span className={billingCycle === 'annually' ? 'text-blue-600 font-medium' : 'text-gray-500'}>
                Yearly
              </span>
              <span className="ml-2 inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800">
                Save 20%
              </span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`bg-white rounded-xl shadow-lg overflow-hidden border transition-all ${
                plan.popular
                  ? 'border-blue-400 md:-mt-4 md:mb-4 relative z-10 scale-105'
                  : 'border-gray-100'
              }`}
            >
              {plan.popular && (
                <div className="bg-blue-600 text-white text-center py-2 text-sm font-medium">
                  Most Popular
                </div>
              )}
              <div className="p-8">
                <h3 className="text-xl font-bold">{plan.name}</h3>
                <div className="mt-4 mb-6">
                  <div className="flex items-baseline">
                    <span className="text-4xl font-bold">
                      {billingCycle === 'monthly' ? plan.price.monthly : plan.price.annually}
                    </span>
                    <span className="text-gray-500 ml-2">/month</span>
                  </div>
                  {billingCycle === 'annually' && (
                    <div className="text-sm text-green-600 mt-1">
                      Billed annually
                    </div>
                  )}
                </div>
                <p className="text-gray-600 mb-6">{plan.description}</p>
                <Button
                  variant={plan.popular ? 'primary' : 'outline'}
                  fullWidth
                >
                  {plan.cta}
                </Button>
              </div>

              <div className="bg-gray-50 p-8">
                <p className="font-medium mb-4">What's included:</p>
                <ul className="space-y-3">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                  {plan.notIncluded?.map((feature, index) => (
                    <li key={`not-${index}`} className="flex items-start">
                      <X className="h-5 w-5 text-gray-400 mr-2 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-500">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </Container>
    </section>
  );
};

export default PricingSection;